package br.edu.ifpi.dengue.controllers;

import br.edu.ifpi.dengue.models.Notificacao;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@Controller
public class NotificacaoController{
     private List<Notificacao> notificacoes = new ArrayList<>();
    private Logger logger = Logger.getLogger(NotificacaoController.class.getName());

    /*@GetMapping("/adicionar")
    public String adicionarNotificacao(){
        return "notificacao-adicionar";
    }*/

    @PostMapping("/add")
        public String cadastrar(@ModelAttribute Notificacao notificacao) {


            notificacoes.add(notificacao);

            return "redirect:/cadastrar";
        }
}
