package br.edu.ifpi.dengue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChikungunyaApplicationTests {

    @Test
    void contextLoads() {
    }

}
